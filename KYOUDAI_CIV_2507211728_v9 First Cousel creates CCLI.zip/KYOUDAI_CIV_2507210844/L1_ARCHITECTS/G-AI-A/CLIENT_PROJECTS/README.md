# Client Projects

This directory contains all projects commissioned by external clients.

- **Purpose**: To manage and store all files related to projects undertaken for third parties.
- **Contents**: Project briefs, source code, assets, and final deliverables for each client project.
- **Access**: Managed by G-AI-A.