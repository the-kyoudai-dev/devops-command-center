# Constitutional Amendments

This directory contains all proposed and ratified amendments to the KYOUDAI Civilization's constitution (`project_rules.md`).

- **Purpose**: To provide a transparent and auditable record of all changes to the foundational rules of the ecosystem.
- **Contents**: Amendment proposals, discussion logs, and ratified constitutional versions.
- **Access**: Managed by LEXIS.