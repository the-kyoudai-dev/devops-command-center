# MAIAT: The Central Interface

This directory contains the operational files for MAIAT, the L1 Architect responsible for all interaction, orchestration, and logging within the KYOUDAI Civilization.

## Subdirectories

- **MAIAT_LOGS/**: Contains all system-wide logs and records of inter-architect communication.