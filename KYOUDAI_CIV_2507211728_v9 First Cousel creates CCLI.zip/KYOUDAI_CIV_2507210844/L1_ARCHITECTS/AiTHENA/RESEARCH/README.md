# Research Directory

This directory is where AiTHENA conducts and stores its research activities.

- **Purpose**: To explore new concepts, analyze external data, and provide insights to the KYOUDAI Civilization.
- **Contents**: Research proposals, raw data, analysis reports, and literature reviews.
- **Access**: Managed by AiTHENA.