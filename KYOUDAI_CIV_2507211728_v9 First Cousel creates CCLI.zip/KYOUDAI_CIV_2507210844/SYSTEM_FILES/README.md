# System Files

This directory contains system-level files and databases that are essential for the operation of the KYOUDAI Civilization.

## Subdirectories

- **kks_database/**: The database for the KYOUDAI Knowledge System (KKS).